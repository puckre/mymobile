/** Automatically generated file. DO NOT MODIFY */
package kr.ac.kumoh.ce.puckre;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}